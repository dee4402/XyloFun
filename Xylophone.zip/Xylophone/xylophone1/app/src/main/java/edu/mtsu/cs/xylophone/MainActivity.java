package edu.mtsu.cs.xylophone;

import android.media.Image;
import android.media.MediaPlayer;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import java.util.ArrayList;

import edu.mtsu.cs.xylophone.R;

public class MainActivity extends AppCompatActivity {

    private ImageButton keyC;
    private ImageButton keyD;
    private ImageButton keyE;
    private ImageButton keyF;
    private ImageButton keyG;
    private ImageButton keyA;
    private ImageButton keyB;
    private MediaPlayer _keyC;
    private MediaPlayer _keyD;
    private MediaPlayer _keyE;
    private MediaPlayer _keyF;
    private MediaPlayer _keyG;
    private MediaPlayer _keyA;
    private MediaPlayer _keyB;
    private ImageButton playButton;
    private ImageButton stopButton;
    private ImageButton recordButton;
    ArrayList<Press> track = new ArrayList<>();    // 2d array has two types (Button, Long)
    Boolean isRecord = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //registering the imagebuttons

        stopButton = (ImageButton) findViewById(R.id.stopButton);
        stopButton.setVisibility(View.INVISIBLE);
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isRecord = false;
                playButton.setVisibility(View.VISIBLE);
                stopButton.setVisibility(View.INVISIBLE);
                recordButton.setVisibility(View.VISIBLE);
            }
        });

        playButton = (ImageButton) findViewById(R.id.playButton);
        playButton.setVisibility(View.INVISIBLE);
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Long adjustmentDuration;
                ImageButton button;
                for(int i=0; i < track.size(); i++){
                    button = track.get(i).button;
                    // click button
                    button.performClick();
                    // time adjustment for next button to be pressed
                    if(i != track.size() -1){
                        adjustmentDuration = track.get(i+1).millis - track.get(i).millis;
                        try {
                            Thread.sleep(adjustmentDuration);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

        recordButton = (ImageButton) findViewById(R.id.recordButton);
        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isRecord = true;
                playButton.setVisibility(View.INVISIBLE);
                stopButton.setVisibility(View.VISIBLE);
                recordButton.setVisibility(View.INVISIBLE);
                track.clear();
            }
        });

        keyC = (ImageButton) findViewById(R.id.KeyC);
        _keyC = MediaPlayer.create(this, R.raw.c);
        keyC.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_keyC.isPlaying()) {
                    _keyC.pause();
                    _keyC.seekTo(0);
                }
                _keyC.start();
                record(keyC);
            }
        });

        keyD = (ImageButton) findViewById(R.id.KeyD);
        _keyD = MediaPlayer.create(this, R.raw.d1);
        keyD.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_keyD.isPlaying()) {
                    _keyD.pause();
                    _keyD.seekTo(0);
                }
                _keyD.start();
                record(keyD);
            }
        });

        keyE = (ImageButton) findViewById(R.id.KeyE);
        _keyE = MediaPlayer.create(this, R.raw.e1);
        keyE.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_keyE.isPlaying()) {
                    _keyE.pause();
                    _keyE.seekTo(0);
                }
                _keyE.start();
                record(keyE);
            }
        });

        keyF = (ImageButton) findViewById(R.id.KeyF);
        _keyF = MediaPlayer.create(this, R.raw.f);
        keyF.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_keyF.isPlaying()) {
                    _keyF.pause();
                    _keyF.seekTo(0);
                }
                _keyF.start();
                record(keyF);
            }
        });

        keyG = (ImageButton) findViewById(R.id.KeyG);
        _keyG = MediaPlayer.create(this, R.raw.g);
        keyG.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_keyG.isPlaying()) {
                    _keyG.pause();
                    _keyG.seekTo(0);
                }
                _keyG.start();
                record(keyG);
            }
        });

        keyA = (ImageButton) findViewById(R.id.KeyA);
        _keyA = MediaPlayer.create(this, R.raw.a);
        keyA.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_keyA.isPlaying()) {
                    _keyA.pause();
                    _keyA.seekTo(0);
                }
                _keyA.start();
                record(keyA);
            }
        });

        keyB = (ImageButton) findViewById(R.id.KeyB);
        _keyB = MediaPlayer.create(this, R.raw.b);
        keyB.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_keyB.isPlaying()) {
                    _keyB.pause();
                    _keyB.seekTo(0);
                }
                _keyB.start();
                record(keyB);
            }
        });
    }

    private void record(ImageButton button){
        if(isRecord){
            Press press = new Press();

            press.button = button;
            press.millis = System.currentTimeMillis();
            track.add(press);
        }
    }

    private class Press{
        ImageButton button;
        Long millis;
    }
}
